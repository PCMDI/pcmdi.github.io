<?

$title = "PCMDI > Projects > Detection / Attribution > Synthetic MSU Data";
$header_image = "http://www-pcmdi.llnl.gov/images/banner_projects.jpg";
$welcome_image = "http://www-pcmdi.llnl.gov/images/headers/detection_attribution.jpg";

require ("http://www-pcmdi.llnl.gov/header.inc");

?>
<style type="text/css">
<!--
.style1 {color: #AA0000}
-->
</style>


                        <center> 
                          <p><b class="size24">Synthetic Microwave Sounding Unit (MSU) Datasets</b></p>

			  <p>(LLNL-MI-409571)</p>

                        </center>
                  
                        <p>The datasets are described in the document &quot;<a href="MSU_doc.pdf">Information Regarding Synthetic Microwave Sounding Unit (MSU) Temperatures Calculated from CMIP-3 Archive</a>&quot;. Potential users should download and read this document before downloading the datasets. No additional documentation nor additional support for these data can be provided.</p>
                       
			<p>Publications using any or all of the synthetic MSU T<sub>2</sub> temperatures and/or the synthetic T<sub>2LT</sub> temperatures should reference these datasets as follows:</p>

			<p>&quot;Synthetic MSU temperatures from 49 simulations of 20<sup>th</sup> century climate change were calculated as described in Santer, B.D., et al., 2008: Consistency of modeled and observed temperature trends in the tropical troposphere. <i>International Journal of Climatology</i>, <b>28</b>, 1703-1722, doi:10.1002/joc.1756.&quot;</p>

			<p>The datasets are available as two GZIP archives of 49 ASCII files each. Open source utilities to extract the files from the archive on computers running the Windows and UNIX operating systems are available at <a href="http://www.gzip.org">http://www.gzip.org</a>.  File extraction was tested using the commercial software package WinZip (<a href="http://www.winzip.com">http://www.winzip.com</a>) on a Windows XP computer system.</p>
			
			<p class="style1">New data (April 2010):
<table border=0>
                            <tr>
                              <td>&nbsp;&nbsp;&nbsp;&nbsp;T<sub>2</sub> data:</td>
                              <td>&nbsp;&nbsp;&nbsp;&nbsp;<a href="tam2.tar.gz">tam2.tar.gz</a></td>
                            </tr>
			    <tr>
                              <td>&nbsp;&nbsp;&nbsp;&nbsp;T<sub>2LT</sub> data:</td>
                              <td>&nbsp;&nbsp;&nbsp;&nbsp;<a href="tam6.tar.gz">tam6.tar.gz</a></td>
                            </tr>
                          </table>
			</p>

<br>

			<p>This data available on this site was prepared as an account of work sponsored by an agency of the United States government. Neither the United States government nor Lawrence Livermore National Security, LLC, nor any of their employees makes any warranty, expressed or implied, or assumes any legal liability or responsibility for the accuracy, completeness, or usefulness of any information, apparatus, product, or process disclosed, or represents that its use would not infringe privately owned rights. Reference herein to any specific commercial product, process, or service by trade name, trademark, manufacturer, or otherwise does not necessarily constitute or imply its endorsement, recommendation, or favoring by the United States government or Lawrence Livermore National Security, LLC. The views and opinions of authors expressed herein do not necessarily state or reflect those of the United States government or Lawrence Livermore National Security, LLC, and shall not be used for advertising or product endorsement purposes.</p>
			<p><span class="style1">Data withdrawn:</span>  Please note that for the CNRM model, the air temperature data (&quot;ta&quot;) were reported to PCMDI on only 12 layers for the period 1860-1899, but on all 17 standard pressure levels for the subsequent years of the historical run (1900-2000).  When the CNRM ta data first arrived at PCMDI, they were processed incorrectly for the period before 1960. The data were assumed  to be similar to those of all other models we had processed, and to exist on the same number of levels throughout the simulation.  Subsequently, the processing of ta data was corrected, with results correctly stored on 12 levels before 1900 and 17 levels thereafter. The synthetic MSU temperatures were computed before the error in the CNRM ta data was noticed. For this reason, <strong>as of April 2010, the incorrect CNRM synthetic MSU temperatures from 1860-1959 have been removed from the PCMDI website. </strong>The CNRM synthetic MSU temperature data from 1960 to 2000 are correct and remain available.  It should be noted that PCMDI scientists have not published any articles that use CNRM synthetic MSU temperature data for the period prior to 1960.  Thus, there is no need to revise any published results.</p>
<p>This work performed under the auspices of the U.S. Department of Energy by Lawrence Livermore National Laboratory under Contract DE-AC52-07NA27344.</p>

<br>
<br>

<?

require ("http://www-pcmdi.llnl.gov/footer.inc");

?>
