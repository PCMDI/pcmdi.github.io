<?

$title = "PCMDI > Projects > Detection / Attribution > Synthetic MSU Data 2011";
$header_image = "http://www-pcmdi.llnl.gov/images/banner_projects.jpg";
$welcome_image = "http://www-pcmdi.llnl.gov/images/headers/detection_attribution.jpg";

require ("http://www-pcmdi.llnl.gov/header.inc");

?>
<style type="text/css">
<!--
.style1 {color: #AA0000}
-->
</style>


                        <center> 
                          <p><b class="size24">New Synthetic Microwave Sounding Unit (MSU) Datasets 2011, <br />
                          Developed using Method by C. Mears, 2011</b></p>

			  <p><em>(LLNL-MI-499392)</em></p>

                        </center>
                  
                        <p>The details of the datasets are described in the '<a href="JGR_Santer_etal_Supporting_Material_16aug11.pdf">Supporting Material</a>'.Potential users should download and read this document before downloading the datasets. No additional documentation nor additional support for these data can be provided.</p>
                        <p>The data was developed using a new method by Carl Mears at Remote Sensing Systems in Santa Rosa, California, and is  documented in a scientific paper currently under review at the Journal of Atmospheric and Oceanic Technology</p>
                        <p>Mears, C.A., B.D. Santer, C.S. Doutriaux, and F.J. Wentz,<strong> 2011</strong>: Calculating synthetic microwave sounder brightness temperatures from discrete-level data. <em>Journal of Atmospheric and Oceanic Technology</em> (in review).</p>
                       
			<p>Publications using any or all of the synthetic MSU T<sub>2</sub> temperatures and/or the synthetic T<sub>2LT</sub> temperatures should reference these datasets as follows:</p> 
            
         <p>Santer, B.D., C. Mears, C. Doutriaux, P. Caldwell, P.J. Gleckler, T.M.L. Wigley, S. Solomon, N.P. Gillett, D. Ivanova, T.R. Karl, J.R. Lanzante, G.A. Meehl, P.A. Stott, K.E. Taylor, P.W. Thorne, M.F. Wehner, and F.J. Wentz,<strong> 2011</strong>: Separating signal and noise in atmospheric temperature changes: The importance of timescale. <em>Journal of Geophysical Research</em> (Atmospheres) doi:<a href="http://dx.doi.org/doi:10.1029/2011JD016263">10.1029/2011JD016263</a>, in press (available online in the JGR "Papers in press" section).</p>
            
            
			<p class="style1">2011 MSU temperature data:
<table border=0  >
                            <tr>
                             
                              <td>&nbsp;&nbsp;&nbsp;&nbsp;<a href="TLT_ex20c3m.tar">TLT_ex20c3m.tar</a></td>
                            </tr>
			                <tr>
                               <td>&nbsp;&nbsp;&nbsp;&nbsp;<a href="TLT_picntrl.tar">TLT_picntrl.tar</a></td>
                            </tr><tr>
                               
                              <td>&nbsp;&nbsp;&nbsp;&nbsp;<a href="SST_ex20c3m.tar">SST_ex20c3m.tar</a></td>
                            </tr>
                          </table>
<p>&quot;<a href="TLT_picntrl.tar">TLT_picntrl.tar</a>&quot; contains time series of monthly-mean lower 
              tropospheric temperature anomalies from the 29 CMIP-3 pre-industrial 
              control runs described in Table S3 of the document appended to this 
              email [this document is the online &quot;<a href="JGR_Santer_etal_Supporting_Material_16aug11.pdf">Supporting Material</a>&quot; for Santer et 
              al (2011)].</p>
            <p>&quot;<a href="TLT_ex20c3m.tar">TLT_ex20c3m.tar</a>&quot; contains time series of monthly-mean lower 
              tropospheric temperature anomalies from the 51 CMIP-3 simulations of 
              historical climate change (the spliced 20CEN/SRES A1B simulations). 
              These runs are described in Table S2 of the appended document.</p>
            <p>All synthetic MSU temperature data in &quot;<a href="TLT_picntrl.tar">TLT_picntrl.tar</a>&quot; and 
              &quot;<a href="TLT_ex20c3m.tar">TLT_ex20c3m.tar</a>&quot; were spatially-averaged over 82.5 degrees N to 70 
              degrees S.</p>
            <p>The third tar file &quot;<a href="SST_ex20c3m.tar">SST_ex20c3m.tar</a>&quot; contains the CMIP-3 sea-surface temperature (SST) 
              data used for producing Figure 10 in Santer et al. (2011). </p>
            <p>&quot;<a href="TLT_ex20c3m.tar">SST_ex20c3m.tar</a>&quot; consists of time series of monthly-mean SST anomalies  
              from 50 CMIP-3 simulations of historical climate change (the 51 spliced 
              20CEN/SRES A1B simulations in Table S2, minus the ncar_pcm_run2, which 
              begins in 1961, and does not cover the full 1947-2010 period used for 
              analyzing SST data). All SST data in &quot;SST_ex20c3m.tar&quot; were 
              spatially-averaged over 50 degrees N to 50 degrees S.</p>
            <p><br>
              
            </p>
            <i><p>This data available on this site was prepared as an account of work sponsored by an agency of the United States government. Neither the United States government nor Lawrence Livermore National Security, LLC, nor any of their employees makes any warranty, expressed or implied, or assumes any legal liability or responsibility for the accuracy, completeness, or usefulness of any information, apparatus, product, or process disclosed, or represents that its use would not infringe privately owned rights. Reference herein to any specific commercial product, process, or service by trade name, trademark, manufacturer, or otherwise does not necessarily constitute or imply its endorsement, recommendation, or favoring by the United States government or Lawrence Livermore National Security, LLC. The views and opinions of authors expressed herein do not necessarily state or reflect those of the United States government or Lawrence Livermore National Security, LLC, and shall not be used for advertising or product endorsement purposes.</p> 
<p>This work performed under the auspices of the U.S. Department of Energy by Lawrence Livermore National Laboratory under Contract DE-AC52-07NA27344.</p></i>

<br>
<br>

<?

require ("http://www-pcmdi.llnl.gov/footer.inc");

?>
